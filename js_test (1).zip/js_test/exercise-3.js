/*------------------------------------------------------------------------------
It is strictly forbidden to use numbers,
 and you can use the values of variables along with what you have learned to implement what is required
It is required to print numbers only from the beginning of the number two to the end
Think a little logically about how you will make the loop ignore the number 1
You must use the Loop For to do the required thing
------------------------------------------------------------------------------*/

let mix = [1, 2, 3, "A", "B", "C", 4];

// TODO solve this fill the for loop with the correct data
for ( ;  ; ) {
    
  }


// Output
// 2
// 3
// 4

