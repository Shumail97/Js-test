# Introduction

For the test we are going to ask you to do a couple of smaller JS exercises. The goal of the test is to be able to see how far along everyone is in the process to becoming a developer so that we can make the decision if you are ready to start using JavaScript in a project or if you need to practice the fundamentals some more. So try your best to get as far as you can!

## Goal / Requirements

Go through all of the `question-x.js` files. At the top of the file there is an explanation of what you need to do. Read through that carefully and write the javascript needed to solve the problem.

Once you have completed all of the questions (or it is time to hand in), create a `zip` file containing your answers and send that file to @islam osman on slack.

## Grading

Every question has a certain amount of points associated with that question. Spend your time wisely, if you get stuck on a question, move on to the next one.

- Question 1 [up to 2 points]
- Question 2 [up to 3 points]
- Question 3 [up to 4 points]
- Question 4 [up to 4 points]
- Question 5 [up to 3 points]
- Code is nicely organized and clean [up to 4 points]
  - No more `console.log` test lines
  - No commented out code
  - Comments for functions/lines of code that can be unclear for other programmers or yourself in 5 months
  - Are the variables/functions named nicely
  - Check that the code is split logically (no repeated code in multiple functions)

Make sure you spend the time to clean up your code as we will grade on that too!

## Rules during the exam

1. You are allowed to use Google.
2. No contact with others during the test.
3. It's not allowed to use chatgpt
4. Do not share your test with anybody.
5. Hand in your work on time. You have 3 hours in total, Hand in after the time will consider as failed.
