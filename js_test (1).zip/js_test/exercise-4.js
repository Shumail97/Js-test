/*------------------------------------------------------------------------------
Create a Function that performs various mathematical operations
The function accepts three parameters: the first and second numbers and the type of arithmetic operation
The function performs the mathematical operation that you write on the two numbers,
 and it contains only 3 operations (add | subtract | multiply)
If the type of calculation is not written, add the two numbers
If only one number is written in the function,
 a message is displayed in the console stating that the second number does not exist
------------------------------------------------------------------------------*/

function calculate(firstNum, secondNum, operation) {
    // TODO code goes here 
  }
  
  // ! Needed Output
  calculate(20); // Second Number Not Found
  calculate(20, 30); // 50
  calculate(20, 30, 'add'); // 50
  calculate(20, 30, 'subtract'); // -10
  calculate(20, 30, 'multiply'); // 600